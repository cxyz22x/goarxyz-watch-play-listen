(function () {
  if (document.getElementById("goar-site-nav")) return;
  const here = (location.pathname || "").replace(/\/+$/, "") || "/";
  const links = [
    { href: "index.html", label: "Home", match: /(^|\/)(index\.html)?$/ },
    { href: "goarxyz.html?tab=movie", label: "Movies", match: /goarxyz\.html/ },
    { href: "goarxyz.html?tab=tv", label: "TV", match: /tab=tv/ },
    { href: "music.html", label: "Music", match: /music\.html/ },
    { href: "games.html", label: "Games", match: /games/ }
  ];
  const css = document.createElement("style");
  css.textContent = [
    "#goar-site-nav{position:fixed;left:50%;transform:translateX(-50%);bottom:18px;z-index:9999;",
    "display:flex;gap:6px;padding:6px;border-radius:999px;background:rgba(16,16,22,.92);",
    "border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(16px);",
    "box-shadow:0 12px 40px rgba(0,0,0,.45);font-family:Inter,system-ui,sans-serif}",
    "#goar-site-nav a{color:#b8bcc8;text-decoration:none;font-size:12px;font-weight:700;",
    "letter-spacing:.04em;text-transform:uppercase;padding:10px 14px;border-radius:999px}",
    "#goar-site-nav a.on,#goar-site-nav a:hover{color:#fff;background:#1c1c24}",
    "@media (max-width:720px){#goar-site-nav{bottom:10px;gap:2px}#goar-site-nav a{padding:9px 10px;font-size:10px}}",
    "body.goar-has-site-nav{padding-bottom:84px}"
  ].join("");
  document.documentElement.appendChild(css);
  const nav = document.createElement("nav");
  nav.id = "goar-site-nav";
  nav.setAttribute("aria-label", "Site");
  links.forEach((item) => {
    const a = document.createElement("a");
    a.href = item.href;
    a.textContent = item.label;
    const q = location.search || "";
    const path = here + q;
    if (item.label === "Home" && /(?:\/$|index\.html$)/.test(here) && here.indexOf("games") === -1 && here.indexOf("music") === -1 && here.indexOf("goarxyz") === -1) a.className = "on";
    if (item.label === "Movies" && /goarxyz\.html/.test(path) && !/[?&]tab=tv/.test(q)) a.className = "on";
    if (item.label === "TV" && /[?&]tab=tv/.test(q)) a.className = "on";
    if (item.label === "Music" && /music/.test(here)) a.className = "on";
    if (item.label === "Games" && /games/.test(here)) a.className = "on";
    nav.appendChild(a);
  });
  function mount() {
    if (!document.body) return;
    document.body.appendChild(nav);
    document.body.classList.add("goar-has-site-nav");
  }
  if (document.body) mount();
  else document.addEventListener("DOMContentLoaded", mount);
})();
