import type { IncomingMessage, ServerResponse } from 'node:http';
import { serveStatic } from './static.js';
import { relayHlsStream } from '../relay/hls.js';
import { parseResolveInput } from '../resolve/input.js';
import { stream } from '../resolve/run.js';

const cors = { 'Access-Control-Allow-Origin': '*' } as const;

function json(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'Content-Type': 'application/json', ...cors });
  res.end(JSON.stringify(body));
}

async function ndjson(
  res: ServerResponse,
  generator: AsyncGenerator<unknown>,
): Promise<void> {
  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
    ...cors,
  });
  res.flushHeaders?.();
  res.socket?.setNoDelay(true);
  for await (const event of generator) {
    const line = `${JSON.stringify(event)}\n`;
    await new Promise<void>((resolve, reject) => {
      res.write(line, (error) => (error ? reject(error) : resolve()));
    });
  }
  res.end();
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export async function route(req: IncomingMessage, res: ServerResponse): Promise<void> {
  if (!req.headers.host) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('missing host');
    return;
  }
  if (req.url === undefined) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('missing url');
    return;
  }

  const { pathname, searchParams, origin } = new URL(req.url, `http://${req.headers.host}`);

  if (pathname === '/api/hls') {
    const target = searchParams.get('url');
    if (!target) {
      json(res, 400, { error: 'url required' });
      return;
    }
    try {
      const out = await relayHlsStream(target, `${origin}/api/hls`);
      res.writeHead(out.status, out.headers);
      res.end(out.body);
    } catch (error) {
      json(res, 502, { error: errorMessage(error) });
    }
    return;
  }

  if (pathname === '/api/resolve') {
    try {
      await ndjson(
        res,
        stream(
          parseResolveInput({
            type: searchParams.get('type'),
            id: searchParams.get('id'),
            season: searchParams.get('season'),
            episode: searchParams.get('episode'),
          }),
          origin,
          searchParams.get('server') ?? undefined,
        ),
      );
    } catch (error) {
      if (res.headersSent) {
        res.end();
        return;
      }
      const stage =
        typeof error === 'object' &&
        error !== null &&
        'stage' in error &&
        typeof error.stage === 'string'
          ? error.stage
          : 'input';
      json(res, 400, { ok: false, stage, error: errorMessage(error) });
    }
    return;
  }

  if (serveStatic(pathname, res)) return;

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('not found');
}
