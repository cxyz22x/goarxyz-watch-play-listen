import { resolveSources, type ResolveInput } from '../vidrock/api.js';
import type { DecryptedSource } from '../vidrock/crypto.js';
import { playUrl } from '../relay/link.js';
import { profileByName } from '../servers/index.js';
import { vidrockOrigin } from '../env.js';

type ServerHint = {
  name: string;
  format: 'hls' | 'mp4';
};

type ResolvedOk = {
  name: string;
  status: 'ok';
  ms: number;
  url: string;
  play: string | null;
  format: 'hls' | 'mp4';
  needsProxy: boolean;
  directPlayable: boolean;
  referer: string;
  origin: string;
};

type ResolveEvent =
  | { event: 'meta'; title: string }
  | { event: 'servers'; servers: ServerHint[] }
  | { event: 'server'; server: { name: string; status: 'loading' } }
  | { event: 'server'; server: { name: string; status: 'fail'; ms: number } }
  | { event: 'server'; server: ResolvedOk };

async function* openOne(
  source: DecryptedSource,
  siteOrigin: string,
): AsyncGenerator<ResolveEvent> {
  const profile = profileByName(source.name);
  yield { event: 'server', server: { name: source.name, status: 'loading' } };
  const started = Date.now();

  if (!profile) {
    yield {
      event: 'server',
      server: { name: source.name, status: 'fail', ms: Date.now() - started },
    };
    return;
  }

  let url = source.url;
  if (profile.normalizeUrl) {
    try {
      url = await profile.normalizeUrl(source.url);
    } catch {
      yield {
        event: 'server',
        server: { name: source.name, status: 'fail', ms: Date.now() - started },
      };
      return;
    }
  }

  yield {
    event: 'server',
    server: {
      name: source.name,
      status: 'ok',
      ms: Date.now() - started,
      url,
      play: profile.needsProxy ? playUrl(siteOrigin, url) : null,
      format: source.format,
      needsProxy: profile.needsProxy,
      directPlayable: profile.directPlayable,
      referer: `${vidrockOrigin}/`,
      origin: vidrockOrigin,
    },
  };
}

export async function* stream(
  input: ResolveInput,
  siteOrigin: string,
  onlyName?: string,
): AsyncGenerator<ResolveEvent> {
  const sources = await resolveSources(input);
  const queue = onlyName
    ? sources.filter((source) => source.name === onlyName)
    : sources;

  if (onlyName && queue.length === 0) {
    throw Object.assign(new Error(`unknown server: ${onlyName}`), { stage: 'resolve' });
  }

  yield {
    event: 'meta',
    title: input.kind === 'tv' ? `TV ${input.id}` : `Movie ${input.id}`,
  };

  yield {
    event: 'servers',
    servers: sources.map((source) => ({
      name: source.name,
      format: source.format,
    })),
  };

  let ok = false;
  for (const source of queue) {
    for await (const event of openOne(source, siteOrigin)) {
      yield event;
      if (event.event === 'server' && event.server.status === 'ok') ok = true;
    }
    if (!onlyName && ok) break;
  }

  if (!ok) {
    throw Object.assign(new Error('no playable servers'), { stage: 'resolve' });
  }
}
