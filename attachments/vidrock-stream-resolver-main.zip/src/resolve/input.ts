import type { ResolveInput } from '../vidrock/api.js';

export function parseResolveInput(params: {
  type: string | null;
  id: string | null;
  season: string | null;
  episode: string | null;
}): ResolveInput {
  const kind = params.type === 'tv' ? 'tv' : 'movie';
  const id = (params.id ?? '').trim();
  if (id.length === 0) throw new Error('id required');

  if (kind === 'tv') {
    const season = Number(params.season);
    const episode = Number(params.episode);
    if (!Number.isInteger(season) || season < 1) throw new Error('season required');
    if (!Number.isInteger(episode) || episode < 1) throw new Error('episode required');
    return { kind, id, season, episode };
  }

  return { kind, id };
}
