import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { userAgent } from '../env.js';

const exec = promisify(execFile);

export type CurlTextResult = {
  status: number;
  body: string;
  buffer: Buffer;
};

export type CurlBinaryResult = {
  status: number;
  body: Buffer;
  buffer: Buffer;
};

type CurlOptions = {
  headers?: Record<string, string>;
  binary?: boolean;
  range?: string;
  connectTimeout?: number;
  maxTime?: number;
};

export async function curl(
  url: string,
  options?: Omit<CurlOptions, 'binary'> & { binary?: false },
): Promise<CurlTextResult>;
export async function curl(
  url: string,
  options: Omit<CurlOptions, 'binary'> & { binary: true },
): Promise<CurlBinaryResult>;
export async function curl(
  url: string,
  options: CurlOptions = {},
): Promise<CurlTextResult | CurlBinaryResult> {
  const connectTimeout = options.connectTimeout ?? 15;
  const maxTime = options.maxTime ?? 60;
  const args = [
    '-sS',
    '-L',
    '--compressed',
    '--connect-timeout',
    String(connectTimeout),
    '--max-time',
    String(maxTime),
  ];
  const hdrs: Record<string, string> = {
    'User-Agent': userAgent,
    Accept: '*/*',
    ...options.headers,
  };
  if (options.range) hdrs.Range = options.range;
  for (const [key, value] of Object.entries(hdrs)) {
    args.push('-H', `${key}: ${value}`);
  }
  args.push('-o', '-', '-w', 'HTTPSTATUS:%{http_code}', url);

  const { stdout } = await exec('curl', args, {
    maxBuffer: 64 * 1024 * 1024,
    encoding: 'buffer',
  });

  const mark = stdout.lastIndexOf(Buffer.from('HTTPSTATUS:'));
  if (mark < 0) throw new Error('curl response parse failed');
  const buffer = stdout.subarray(0, mark);
  const status = Number(stdout.subarray(mark + 11).toString('utf8'));
  if (!Number.isFinite(status)) throw new Error('curl status parse failed');

  if (options.binary) {
    return { status, body: buffer, buffer };
  }
  return { status, body: buffer.toString('utf8'), buffer };
}
