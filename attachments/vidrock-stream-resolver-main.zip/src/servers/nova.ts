import { type ServerProfile, vidrockBrowserHeaders } from './types.js';

export const nova: ServerProfile = {
  name: 'Nova',
  hosts: ['cdn.ngcorp.dad'],
  needsProxy: true,
  directPlayable: false,
  headers: { ...vidrockBrowserHeaders },
};
