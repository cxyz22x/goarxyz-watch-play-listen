import { atlas } from './atlas.js';
import { astra } from './astra.js';
import { luna } from './luna.js';
import { nova } from './nova.js';
import { orion } from './orion.js';
import type { ServerProfile } from './types.js';

const servers: readonly ServerProfile[] = [nova, atlas, luna, orion, astra];

export function profileByName(name: string): ServerProfile | null {
  return servers.find((server) => server.name === name) ?? null;
}

export function profileByUrl(url: string): ServerProfile | null {
  const host = new URL(url).hostname;
  return (
    servers.find((server) =>
      server.hosts.some((item) => host === item || host.endsWith(`.${item}`)),
    ) ?? null
  );
}
