import { type ServerProfile, vidrockBrowserHeaders } from './types.js';

export const orion: ServerProfile = {
  name: 'Orion',
  hosts: ['dream.flamingo-e55.workers.dev'],
  needsProxy: true,
  directPlayable: true,
  headers: { ...vidrockBrowserHeaders },
};
