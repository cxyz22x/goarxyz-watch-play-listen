import { userAgent, vidrockOrigin } from '../env.js';

export type ServerProfile = {
  name: string;
  hosts: readonly string[];
  needsProxy: boolean;
  directPlayable: boolean;
  headers: Record<string, string>;
  normalizeUrl?: (url: string) => Promise<string>;
};

export const vidrockBrowserHeaders: Record<string, string> = {
  Referer: `${vidrockOrigin}/`,
  Origin: vidrockOrigin,
  'User-Agent': userAgent,
};
