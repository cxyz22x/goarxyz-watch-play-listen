import { type ServerProfile, vidrockBrowserHeaders } from './types.js';

export const luna: ServerProfile = {
  name: 'Luna',
  hosts: ['dreadnought.flamingo-e55.workers.dev'],
  needsProxy: true,
  directPlayable: true,
  headers: { ...vidrockBrowserHeaders },
};
