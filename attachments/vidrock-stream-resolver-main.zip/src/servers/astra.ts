import { curl } from '../wire/curl.js';
import { type ServerProfile, vidrockBrowserHeaders } from './types.js';

type Quality = { resolution: number; url: string };

async function normalizeAstraUrl(url: string): Promise<string> {
  const res = await curl(url, {
    headers: vidrockBrowserHeaders,
    binary: true,
    connectTimeout: 8,
    maxTime: 15,
  });
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`astra playlist ${res.status}`);
  }
  const raw = JSON.parse(res.buffer.toString('utf8')) as unknown;
  if (!Array.isArray(raw) || raw.length === 0) {
    throw new Error('astra playlist empty');
  }
  const qualities = raw.filter((row): row is Quality => {
    return (
      row !== null &&
      typeof row === 'object' &&
      typeof (row as Quality).resolution === 'number' &&
      typeof (row as Quality).url === 'string'
    );
  });
  if (qualities.length === 0) throw new Error('astra qualities missing');
  qualities.sort((a, b) => b.resolution - a.resolution);
  const best = qualities[0];
  if (!best) throw new Error('astra quality missing');
  return best.url;
}

export const astra: ServerProfile = {
  name: 'Astra',
  hosts: ['streamrk.site', 'v1.streamrk.site'],
  needsProxy: false,
  directPlayable: true,
  headers: { ...vidrockBrowserHeaders },
  normalizeUrl: normalizeAstraUrl,
};
