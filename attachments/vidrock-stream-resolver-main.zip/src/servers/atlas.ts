import { type ServerProfile, vidrockBrowserHeaders } from './types.js';

export const atlas: ServerProfile = {
  name: 'Atlas',
  hosts: ['cdn1.ngcorp.dad'],
  needsProxy: true,
  directPlayable: false,
  headers: { ...vidrockBrowserHeaders },
};
