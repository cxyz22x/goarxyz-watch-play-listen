import { curl } from '../wire/curl.js';
import { sourcesCacheTtlMs, vidrockOrigin } from '../env.js';
import { decryptSourcesPayload, type DecryptedSource } from './crypto.js';

export type ResolveInput =
  | { kind: 'movie'; id: string }
  | { kind: 'tv'; id: string; season: number; episode: number };

type CacheEntry = {
  at: number;
  sources: DecryptedSource[];
};

const cache = new Map<string, CacheEntry>();

function apiPath(input: ResolveInput): string {
  if (input.kind === 'tv') return `tv/${input.id}/${input.season}/${input.episode}`;
  return `movie/${input.id}`;
}

export async function resolveSources(input: ResolveInput): Promise<DecryptedSource[]> {
  const key = apiPath(input);
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < sourcesCacheTtlMs) {
    return hit.sources.map((source) => ({ ...source }));
  }

  const res = await curl(`${vidrockOrigin}/api/${key}`, {
    headers: {
      Referer: `${vidrockOrigin}/`,
      Origin: vidrockOrigin,
    },
    connectTimeout: 8,
    maxTime: 20,
  });
  if (res.status < 200 || res.status >= 300) {
    throw Object.assign(new Error(`api ${res.status}`), { stage: 'api' });
  }
  const payload = JSON.parse(res.body) as unknown;
  if (payload === null || typeof payload !== 'object' || Array.isArray(payload)) {
    throw Object.assign(new Error('api json invalid'), { stage: 'api' });
  }
  const sources = decryptSourcesPayload(payload as Record<string, unknown>);
  cache.set(key, { at: Date.now(), sources });
  return sources.map((source) => ({ ...source }));
}
