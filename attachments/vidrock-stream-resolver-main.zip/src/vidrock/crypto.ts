import { createDecipheriv } from 'node:crypto';

const AES_KEY = Buffer.from(
  '7f3e9c2a8b5d1f4e6a9c3b7d2e5f8a1c4b6d9e2f5a8c1b4d7e9f2a5c8b1d4e7f',
  'hex',
);

const IV_BYTES = 12;
const TAG_BYTES = 16;

type EncryptedSourceEntry = {
  url: string;
  type?: string;
};

export type DecryptedSource = {
  name: string;
  url: string;
  format: 'hls' | 'mp4';
};

function base64UrlToBytes(input: string): Buffer {
  let b64 = input.replace(/-/g, '+').replace(/_/g, '/');
  const pad = b64.length % 4;
  if (pad === 2) b64 += '==';
  else if (pad === 3) b64 += '=';
  else if (pad === 1) throw new Error('invalid base64url length');
  return Buffer.from(b64, 'base64');
}

function decryptStreamUrl(ciphertext: string): string {
  const bytes = base64UrlToBytes(ciphertext);
  if (bytes.length < IV_BYTES + TAG_BYTES) throw new Error('ciphertext too short');
  const iv = bytes.subarray(0, IV_BYTES);
  const packed = bytes.subarray(IV_BYTES);
  const tag = packed.subarray(packed.length - TAG_BYTES);
  const data = packed.subarray(0, packed.length - TAG_BYTES);
  const decipher = createDecipheriv('aes-256-gcm', AES_KEY, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
}

export function decryptSourcesPayload(payload: Record<string, unknown>): DecryptedSource[] {
  const sources: DecryptedSource[] = [];
  for (const [name, entry] of Object.entries(payload)) {
    if (entry === null || typeof entry !== 'object' || Array.isArray(entry)) continue;
    const row = entry as EncryptedSourceEntry;
    if (typeof row.url !== 'string' || row.url.length === 0) continue;
    const type = row.type;
    if (type !== 'hls' && type !== 'mp4') continue;
    sources.push({
      name,
      url: decryptStreamUrl(row.url),
      format: type,
    });
  }
  if (sources.length === 0) throw new Error('empty sources payload');
  return sources;
}
