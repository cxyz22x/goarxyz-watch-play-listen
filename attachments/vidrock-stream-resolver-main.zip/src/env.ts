export const port = Number(process.env.PORT) || 3000;

export const vidrockOrigin = process.env.VIDROCK_ORIGIN ?? 'https://vidrock.net';

export const userAgent =
  process.env.USER_AGENT ??
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export const sourcesCacheTtlMs = Number(process.env.SOURCES_CACHE_TTL_MS) || 60_000;
