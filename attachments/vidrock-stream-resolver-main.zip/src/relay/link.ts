export function playUrl(siteOrigin: string, upstreamUrl: string): string {
  return `${siteOrigin}/api/hls?url=${encodeURIComponent(upstreamUrl)}`;
}
