import { curl } from '../wire/curl.js';
import { profileByUrl } from '../servers/index.js';
import { stripPngPrefix } from './png.js';

type RelayResult = {
  status: number;
  headers: Record<string, string>;
  body: string | Buffer;
};

function rewritePlaylistUrls(text: string, baseUrl: string, relayBase: string): string {
  return text
    .split('\n')
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) {
        if (trimmed.startsWith('#EXT-X-KEY:') || trimmed.startsWith('#EXT-X-MAP:')) {
          return line.replace(/URI="([^"]+)"/g, (_match, uri: string) => {
            const abs = new URL(uri, baseUrl).href;
            return `URI="${relayBase}?url=${encodeURIComponent(abs)}"`;
          });
        }
        return line;
      }
      return `${relayBase}?url=${encodeURIComponent(new URL(trimmed, baseUrl).href)}`;
    })
    .join('\n');
}

export async function relayHlsStream(url: string, relayBase: string): Promise<RelayResult> {
  const profile = profileByUrl(url);
  if (!profile) throw new Error(`unknown upstream host: ${new URL(url).hostname}`);
  if (!profile.needsProxy) throw new Error(`proxy not required for ${profile.name}`);

  const res = await curl(url, { headers: profile.headers, binary: true });
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`upstream ${res.status}`);
  }

  const text = res.buffer.toString('utf8');
  if (text.trimStart().startsWith('#EXTM3U')) {
    return {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.apple.mpegurl',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-cache',
      },
      body: rewritePlaylistUrls(text, url, relayBase),
    };
  }

  return {
    status: 200,
    headers: {
      'Content-Type': 'application/octet-stream',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'public, max-age=3600',
    },
    body: stripPngPrefix(res.buffer),
  };
}
