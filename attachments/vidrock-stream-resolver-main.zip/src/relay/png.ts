export function stripPngPrefix(buffer: Buffer): Buffer {
  if (buffer.length >= 1 && buffer[0] === 0x47) return buffer;
  if (
    buffer.length < 4 ||
    buffer[0] !== 0x89 ||
    buffer[1] !== 0x50 ||
    buffer[2] !== 0x4e ||
    buffer[3] !== 0x47
  ) {
    return buffer;
  }
  const iend = buffer.indexOf(Buffer.from('IEND'));
  if (iend < 0 || iend + 8 >= buffer.length) {
    throw new Error('png-wrapped segment missing IEND');
  }
  return buffer.subarray(iend + 8);
}
