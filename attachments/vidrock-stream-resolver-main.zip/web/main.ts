import { el } from './ui/dom.js';
import { bindCopyButtons, bindExports, clearExports, type ExportFields } from './ui/exports.js';
import { queryParams, readForm, syncType } from './ui/form.js';
import { fromHints, renderServers, type ServerEntry } from './ui/servers.js';
import { createTimers, fmtMs } from './ui/timing.js';
import { createHlsPlayer } from './player/hls.js';
import { consumeResolve, type ResolveEvent } from './api/resolve.js';

const formEl = el<HTMLFormElement>('form');
const form = readForm();
const panel = el('out');
const heading = el('title');
const video = el<HTMLVideoElement>('video');
const err = el('err');
const btn = formEl.querySelector('button');
if (!(btn instanceof HTMLButtonElement)) throw new Error('missing submit button');

const exportFields: ExportFields = {
  direct: el<HTMLInputElement>('direct'),
  browser: el<HTMLInputElement>('browser'),
  vlc: el<HTMLInputElement>('vlc'),
  mpv: el<HTMLInputElement>('mpv'),
};

const serversEl = el('servers');
const player = createHlsPlayer(video);
const timers = createTimers(el('t-resolve'), el('t-play'), el('timing'));

let lastLabel = '';
let lastServers: ServerEntry[] = [];
let lastActive = '';
let selectGen = 0;
let endResolveLive: (() => void) | null = null;

function showErr(message: string): void {
  err.textContent = message;
  err.hidden = false;
}

function paint(): void {
  renderServers(serversEl, lastServers, lastActive, fmtMs);
}

function findServer(name: string): ServerEntry {
  const entry = lastServers.find((item) => item.name === name);
  if (!entry) throw new Error(`unknown server: ${name}`);
  return entry;
}

function mediaSource(entry: ServerEntry): string {
  if (entry.status !== 'ok' || !entry.url) throw new Error(`${entry.name} is not resolved`);
  if (entry.needsProxy) {
    if (!entry.play) throw new Error(`${entry.name} requires proxy URL`);
    return entry.play;
  }
  return entry.url;
}

function live(gen: number): boolean {
  return gen === selectGen;
}

function resetOutput(): void {
  player.stop();
  clearExports(exportFields);
  endResolveLive?.();
  endResolveLive = null;
}

function selectServer(entry: ServerEntry, syncTiming: boolean): number {
  selectGen += 1;
  resetOutput();
  lastActive = entry.name;
  heading.textContent = `${lastLabel} · ${entry.name}`;
  paint();
  if (syncTiming) timers.showServer(entry.resolveMs, null);
  return selectGen;
}

function showExports(entry: ServerEntry): void {
  if (entry.status !== 'ok' || entry.url === null) {
    clearExports(exportFields);
    return;
  }
  bindExports(
    exportFields,
    {
      url: entry.url,
      play: entry.play,
      needsProxy: entry.needsProxy,
      directPlayable: entry.directPlayable,
      referer: entry.referer,
      origin: entry.origin,
    },
    lastLabel,
  );
}

function markPlayFail(entry: ServerEntry): void {
  entry.status = 'fail';
  clearExports(exportFields);
  player.stop();
  timers.showServer(entry.resolveMs, null);
  paint();
}

async function playEntry(entry: ServerEntry, gen: number): Promise<void> {
  if (!live(gen) || entry.status !== 'ok') return;
  showExports(entry);
  timers.showResolve(entry.resolveMs);
  const endPlay = timers.beginPlayback();
  try {
    await player.play(mediaSource(entry), entry.format);
    if (!live(gen)) {
      endPlay();
      return;
    }
    entry.playMs = endPlay();
    timers.showServer(entry.resolveMs, entry.playMs);
  } catch (error) {
    endPlay();
    if (live(gen)) throw error;
  }
}

function applyServerEvent(
  evt: Extract<ResolveEvent, { event: 'server' }>,
  gen: number,
): ServerEntry {
  const entry = findServer(evt.server.name);
  if (!live(gen)) return entry;

  if (evt.server.status === 'loading') {
    entry.status = 'loading';
    entry.resolveMs = null;
    endResolveLive?.();
    endResolveLive = timers.beginResolve();
    lastActive = entry.name;
    heading.textContent = `${lastLabel} · ${entry.name}`;
    clearExports(exportFields);
    paint();
    return entry;
  }

  if (evt.server.status === 'fail') {
    endResolveLive?.();
    endResolveLive = null;
    entry.status = 'fail';
    entry.resolveMs = evt.server.ms;
    clearExports(exportFields);
    timers.showServer(entry.resolveMs, null);
    paint();
    return entry;
  }

  endResolveLive?.();
  endResolveLive = null;
  Object.assign(entry, {
    status: 'ok' as const,
    resolveMs: evt.server.ms,
    url: evt.server.url,
    play: evt.server.play,
    format: evt.server.format,
    needsProxy: evt.server.needsProxy,
    directPlayable: evt.server.directPlayable,
    referer: evt.server.referer,
    origin: evt.server.origin,
  });
  paint();
  return entry;
}

async function openNamed(name: string, gen: number): Promise<ServerEntry> {
  let resolved: ServerEntry | null = null;
  await consumeResolve(
    `/api/resolve?${queryParams(form)}&server=${encodeURIComponent(name)}`,
    async (evt) => {
      if (!live(gen)) return;
      if (evt.event === 'meta' || evt.event === 'servers') return;
      const next = applyServerEvent(evt, gen);
      if (next.status === 'ok') resolved = next;
    },
  );
  if (!live(gen)) throw new Error('cancelled');
  if (!resolved) throw new Error(`${name} failed to resolve`);
  return resolved;
}

function nextIdleName(after?: string): string | null {
  const start = after ? lastServers.findIndex((item) => item.name === after) + 1 : 0;
  for (let i = Math.max(0, start); i < lastServers.length; i += 1) {
    const item = lastServers[i];
    if (item && item.status === 'idle') return item.name;
  }
  return null;
}

async function openAndPlay(name: string, gen: number): Promise<boolean> {
  const entry = await openNamed(name, gen);
  if (!live(gen)) return false;
  try {
    await playEntry(entry, gen);
    return live(gen);
  } catch {
    if (!live(gen)) return false;
    markPlayFail(entry);
    return false;
  }
}

bindCopyButtons();
form.type.addEventListener('change', () => syncType(form));
syncType(form);

serversEl.addEventListener('click', (event) => {
  void (async () => {
    const node = (event.target as HTMLElement).closest('[data-name]');
    if (!(node instanceof HTMLButtonElement)) return;
    const name = node.dataset.name;
    if (!name) return;
    const entry = findServer(name);
    if (name === lastActive && entry.status === 'loading') return;

    err.hidden = true;
    const gen = selectServer(entry, true);

    if (entry.status === 'ok') {
      try {
        await playEntry(entry, gen);
      } catch (e) {
        if (!live(gen)) return;
        markPlayFail(entry);
        showErr(e instanceof Error ? e.message : String(e));
      }
      return;
    }

    if (entry.status === 'loading') return;

    try {
      const ok = await openAndPlay(name, gen);
      if (!live(gen)) return;
      if (!ok) showErr(`${name} failed to play`);
    } catch (e) {
      if (live(gen)) showErr(e instanceof Error ? e.message : String(e));
    }
  })();
});

formEl.addEventListener('submit', (event) => {
  event.preventDefault();
  void (async () => {
    btn.disabled = true;
    err.hidden = true;
    panel.hidden = true;
    selectGen += 1;
    const gen = selectGen;
    resetOutput();
    lastServers = [];
    lastActive = '';
    timers.hide();
    let played = false;
    try {
      await consumeResolve(`/api/resolve?${queryParams(form)}`, async (evt) => {
        if (!live(gen)) return;
        if (evt.event === 'meta') {
          lastLabel = evt.title;
          panel.hidden = false;
          return;
        }
        if (evt.event === 'servers') {
          lastServers = fromHints(evt.servers);
          clearExports(exportFields);
          paint();
          return;
        }
        const entry = applyServerEvent(evt, gen);
        if (!live(gen) || entry.status !== 'ok' || played) return;
        try {
          await playEntry(entry, gen);
          if (live(gen)) played = true;
        } catch {
          if (!live(gen)) return;
          markPlayFail(entry);
        }
      });
      if (!live(gen)) return;

      let cursor = lastActive || undefined;
      while (!played && live(gen)) {
        const next = nextIdleName(cursor);
        if (!next) break;
        cursor = next;
        resetOutput();
        lastActive = next;
        heading.textContent = `${lastLabel} · ${next}`;
        paint();
        timers.showServer(null, null);
        const ok = await openAndPlay(next, gen);
        if (!live(gen)) return;
        if (ok) {
          played = true;
          break;
        }
      }

      if (!played) throw new Error('no playable servers');
    } catch (e) {
      if (!live(gen)) return;
      if (!played) timers.hide();
      showErr(e instanceof Error ? e.message : String(e));
    } finally {
      btn.disabled = false;
    }
  })();
});
