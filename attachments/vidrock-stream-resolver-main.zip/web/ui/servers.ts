export type ServerHint = {
  name: string;
  format: 'hls' | 'mp4';
};

export type ServerEntry = {
  name: string;
  status: 'idle' | 'loading' | 'ok' | 'fail';
  resolveMs: number | null;
  playMs: number | null;
  format: 'hls' | 'mp4';
  url: string | null;
  play: string | null;
  needsProxy: boolean;
  directPlayable: boolean;
  referer: string;
  origin: string;
};

export function fromHints(hints: ServerHint[]): ServerEntry[] {
  return hints.map((hint) => ({
    name: hint.name,
    status: 'idle',
    resolveMs: null,
    playMs: null,
    format: hint.format,
    url: null,
    play: null,
    needsProxy: false,
    directPlayable: false,
    referer: '',
    origin: '',
  }));
}

export function renderServers(
  root: HTMLElement,
  servers: ServerEntry[],
  active: string,
  fmtMs: (ms: number) => string,
): void {
  root.innerHTML = servers
    .map((entry) => {
      const picked = entry.name === active ? ' badge--active' : '';
      const state =
        entry.status === 'ok'
          ? ' badge--ok'
          : entry.status === 'fail'
            ? ' badge--fail'
            : entry.status === 'loading'
              ? ' badge--loading'
              : '';
      const mark =
        entry.status === 'ok'
          ? '<span class="badge__mark">✓</span>'
          : entry.status === 'fail'
            ? '<span class="badge__mark">✕</span>'
            : entry.status === 'loading'
              ? '<span class="badge__mark">…</span>'
              : '';
      const proxy = entry.status === 'ok' && !entry.directPlayable ? ' · proxy' : '';
      const ms =
        entry.resolveMs !== null
          ? `<span class="badge__ms">${fmtMs(entry.resolveMs)}${proxy}</span>`
          : '';
      return `<button type="button" class="badge${state}${picked}" data-name="${entry.name}"${entry.status === 'loading' ? ' disabled' : ''}>${mark}<span class="badge__name">${entry.name}</span>${ms}</button>`;
    })
    .join('');
  const card = root.closest('.card');
  if (card instanceof HTMLElement) card.hidden = servers.length === 0;
}
