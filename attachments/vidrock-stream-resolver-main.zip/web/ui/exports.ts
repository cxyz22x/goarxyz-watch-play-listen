export type ExportFields = {
  direct: HTMLInputElement;
  browser: HTMLInputElement;
  vlc: HTMLInputElement;
  mpv: HTMLInputElement;
};

export type ExportServer = {
  url: string;
  play: string | null;
  needsProxy: boolean;
  directPlayable: boolean;
  referer: string;
  origin: string;
};

function vlcCmd(entry: ExportServer): string {
  return `vlc --http-referrer='${entry.referer}' --http-user-agent='Mozilla/5.0' "${entry.url}"`;
}

function mpvCmd(entry: ExportServer, title: string): string {
  const titleEsc = title.replace(/"/g, '\\"');
  return `mpv --referrer='${entry.referer}' --http-header-fields='Origin: ${entry.origin}' --force-media-title="${titleEsc}" "${entry.url}"`;
}

export function clearExports(fields: ExportFields): void {
  fields.direct.value = '';
  fields.browser.value = '';
  fields.vlc.value = '';
  fields.mpv.value = '';
  for (const field of [fields.browser, fields.vlc, fields.mpv]) {
    const row = field.closest('li');
    if (row instanceof HTMLElement) row.hidden = true;
  }
}

export function bindExports(fields: ExportFields, entry: ExportServer, label: string): void {
  fields.direct.value = entry.url;
  fields.browser.value = entry.play ?? '';
  fields.vlc.value = entry.directPlayable ? vlcCmd(entry) : '';
  fields.mpv.value = entry.directPlayable ? mpvCmd(entry, label) : '';

  const browserRow = fields.browser.closest('li');
  if (browserRow instanceof HTMLElement) browserRow.hidden = !entry.needsProxy;

  const vlcRow = fields.vlc.closest('li');
  if (vlcRow instanceof HTMLElement) vlcRow.hidden = !entry.directPlayable;

  const mpvRow = fields.mpv.closest('li');
  if (mpvRow instanceof HTMLElement) mpvRow.hidden = !entry.directPlayable;
}

export function bindCopyButtons(): void {
  document.querySelectorAll<HTMLButtonElement>('[data-copy]').forEach((node) => {
    node.addEventListener('click', async () => {
      const id = node.dataset.copy;
      if (!id) throw new Error('missing data-copy');
      const field = document.getElementById(id);
      if (!(field instanceof HTMLInputElement)) throw new Error(`missing #${id}`);
      await navigator.clipboard.writeText(field.value);
      const label = node.textContent ?? 'Copy';
      node.textContent = 'Copied';
      node.classList.add('ok');
      window.setTimeout(() => {
        node.textContent = label;
        node.classList.remove('ok');
      }, 1200);
    });
  });
}
