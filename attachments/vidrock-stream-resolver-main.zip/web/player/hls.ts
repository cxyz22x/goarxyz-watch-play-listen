import Hls, { type ErrorData } from 'hls.js';

export function createHlsPlayer(video: HTMLVideoElement) {
  let hls: Hls | null = null;
  let gen = 0;

  function stop(): void {
    gen += 1;
    if (hls) {
      hls.destroy();
      hls = null;
    }
    video.pause();
    video.removeAttribute('src');
    video.load();
  }

  async function play(source: string, format: 'hls' | 'mp4'): Promise<void> {
    stop();
    const id = gen;

    if (format === 'mp4') {
      await new Promise<void>((resolve, reject) => {
        const live = (): boolean => id === gen;
        video.addEventListener(
          'playing',
          () => {
            if (live()) resolve();
          },
          { once: true },
        );
        video.addEventListener(
          'error',
          () => {
            if (live()) reject(new Error('playback failed'));
          },
          { once: true },
        );
        video.src = source;
        void video.play().catch((error: unknown) => {
          reject(error instanceof Error ? error : new Error(String(error)));
        });
      });
      return;
    }

    if (!Hls.isSupported()) throw new Error('HLS not supported');

    await new Promise<void>((resolve, reject) => {
      const live = (): boolean => id === gen;
      const fail = (message: string): void => {
        if (!live()) return;
        reject(new Error(message));
      };

      video.addEventListener(
        'playing',
        () => {
          if (live()) resolve();
        },
        { once: true },
      );
      video.addEventListener('error', () => fail('playback failed'), { once: true });

      hls = new Hls({ enableWorker: true, maxBufferLength: 8, maxMaxBufferLength: 16 });
      hls.on(Hls.Events.ERROR, (_event, data: ErrorData) => {
        if (data.fatal) fail(data.error.message || String(data.details));
      });
      hls.attachMedia(video);
      hls.loadSource(source);
      void video.play().catch((error: unknown) => {
        fail(error instanceof Error ? error.message : String(error));
      });
    });
  }

  return { stop, play };
}
